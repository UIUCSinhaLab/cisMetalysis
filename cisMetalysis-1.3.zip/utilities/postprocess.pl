#!/usr/bin/perl
use strict;
use FindBin qw($Bin);
use File::Basename;
use Getopt::Long;

my $pvalthresh = .05;
my $maxpersize = 1000;
my $brief = undef;

GetOptions("apt=f" => \$pvalthresh, # association pvalue threshold
	"brief"=> \$brief, # output one line per meta-assoc
	"max=f" => \$maxpersize); # maximum number of associations per tuple size

my $infile = $ARGV[0];
my $outdir = $ARGV[1];
mkdir($outdir);

my $base = basename($infile);

my %motifid2name; # maps motif numbers to names
my %tuplempvals; # best meta-pvalue for tuplesize, tuple 
my %statempvals; # meta-pvalue for tuplesize, tuple, state
my %tophowmany; # top how many to combine for tuplesize, tuple, state
my %classpvals; # pvalues for tuplesize, tuple, state, class
my %classinfo; # details for tuplesize, tuple, state, class

my $nstates=0;

warn("Reading Infile...\n");
open(IN,"<$infile") or die "Cannot read $infile\n";
while (<IN>) {
	if (/Evaluating motif tuple, \{(.+)\}/) {
		# read tuple info
		my $tuplestr = $1;
		my @motifsinfo = split(",", $tuplestr);
		my @motifids = ();
		foreach my $m (@motifsinfo){
			$m =~ /M(\d+)\s+\((.+)\)/;
			my $id = $1;
			my $mname = $2;
			$mname =~ s/ //g;
			$mname =~ s/-/./g;
			$mname =~ s/.wtmx//g;
			$motifid2name{$id} = $mname;
			push @motifids, $id;
		}
		my $tuplesize = $#motifids+1;
		my $tuple = join(":",@motifids);
		
		# initialize values
		my %pval = ();
		my %topX = ();
		for (my $i=0; $i<$nstates; $i++) {
			$pval{$i} = 1;
			$topX{$i} = -1;
		} 
		my $curclass = '';
		my $bestpval = 1;

		while (<IN>) {
			if (/Best to combine top (\d+) from state (\d+) with meta p-value of (\S+)/) {
				my $state = $2; 
				if($state > $nstates){$nstates = $state;}
				$topX{$state} = $1;
				$pval{$state} = $3;
				next; 
			}
			if (/The best meta p-value of this tuple is (\S+)/) {
				$bestpval = $1;
				last;
			}
			if (/^(\d+):\s+(.+)\s+ct:\s+(.+)/) {
				my $state = $1;
				my $logicinfo = $2;
				my $ctinfo = $3;
				if($state > $nstates){$nstates = $state;}
				my ($cdir, $pv, $mcombo) = split(/\s+/, $logicinfo);
				my $mlogicinfo = "";
				my $mlogicname = "";
				my $mlogicsize = 0; # number of motifs used in logic
				my $mlogicweight = 0; # weighted number of motifs
				my $andstr = "";
				foreach my $mid (@motifids){
					my $mname = $motifid2name{$mid};
					my $val = 0;
					if($mcombo =~ /-$mid/){ 
						$val = -1;
						$mlogicname = $mlogicname . $andstr . "not $mname"; 
						$mlogicsize++;
						$mlogicweight = $mlogicweight + (1/$tuplesize); 
						$andstr = " & ";
					} elsif ($mcombo =~ /$mid/){
						$val = 1;
						$mlogicname = "$mlogicname$andstr$mname"; 
						$mlogicsize++;
						$mlogicweight++; 
						$andstr = " & ";
					}
					$mlogicinfo = "$mlogicinfo\t$mname\t$val";
				}
				$mlogicweight = $mlogicweight * $cdir; 
				my $tmpinfo = "$cdir$mlogicinfo\t$mlogicname\t$mlogicsize\t$mlogicweight\t$ctinfo";  
				if($pv <= $pvalthresh){
					$classinfo{$tuplesize}{$tuple}{$curclass}{$state} = $tmpinfo;
					$classpvals{$tuplesize}{$tuple}{$state}{$curclass} = $pv;
					next;
				}
			}
			if (/^(\S+)\s+(\S+)$/) {
				$curclass = $1;
				next;
			}		
			warn $_;
		}
		for (my $state=0; $state<=$nstates; $state++) {
			$statempvals{$tuplesize}{$tuple}{$state} = $pval{$state};
			$tophowmany{$tuplesize}{$tuple}{$state} = $topX{$state};
		} 
		$tuplempvals{$tuplesize}{$tuple} = $bestpval;
	}
}
close(IN);

foreach my $tuplesize (sort {$a <=> $b} keys %tuplempvals) {

	if ($tuplesize >= $maxpersize) { next; }

	warn("Processing Tuples of size $tuplesize...\n");
	my $filename = "$base\.$tuplesize\.out.txt";
	open(OUT,">$outdir/$filename") or die "Cannot open $outdir/$filename\n";
	my $mheader = "";
	for(my $i = 1; $i<=$tuplesize; $i++){
		$mheader = "$mheader\tM$i\tM$i\op";
	}

	if(!defined($brief)){ 
		print OUT "tuple#\tstate#\tstateID\tmPval\tcCount\tCondition\taPval\tcDir$mheader\tmCombo\tmCount\tmWeight\tuSize\tcSize\tmSize\tiSize\n"; 
	} else {
		print OUT "file\ttSize\ttuple#\tstate#\tstateID\tmPval\tcCount\n";
	}

	my %tupleseen;
	my $tuplecounter = 0;

	foreach my $tuple (sort {$tuplempvals{$tuplesize}{$a} <=> $tuplempvals{$tuplesize}{$b}} keys %{$tuplempvals{$tuplesize}}) {

		# check if need to process this tuple
		if ($tuplempvals{$tuplesize}{$tuple} > $pvalthresh) { last; }
		my $cantuple = join(":",sort split(":",$tuple));
		if (defined($tupleseen{$cantuple})) { next; }
		$tupleseen{$cantuple} = 1;
		$tuplecounter++;
		if ($tuplecounter >= $maxpersize) { next; }

		# order states
		my @state_order = sort {$statempvals{$tuplesize}{$tuple}{$a} <=> $statempvals{$tuplesize}{$tuple}{$b}} keys %{$statempvals{$tuplesize}{$tuple}};
		my $stcounter = 0;

		foreach my $st (@state_order) {

			$stcounter++;
			my $topX = $tophowmany{$tuplesize}{$tuple}{$st};
			my $mpval = $statempvals{$tuplesize}{$tuple}{$st};

			# order classes 
			my @class_order = sort {$classpvals{$tuplesize}{$tuple}{$st}{$a} <=> $classpvals{$tuplesize}{$tuple}{$st}{$b}} keys %{$classpvals{$tuplesize}{$tuple}{$st}};
			my $classcounter = 0;

			foreach my $class (@class_order) {
				$classcounter++;
				if ($classcounter <= $topX) {
					if(!defined($brief)){
						print OUT "$tuplecounter\t$stcounter\t$st\t$mpval\t$topX\t$class\t";
						print OUT $classpvals{$tuplesize}{$tuple}{$st}{$class} . "\t"; 
						print OUT $classinfo{$tuplesize}{$tuple}{$class}{$st} . "\n";
					} 
				}
			} #end class for	
			if(defined($brief)){
				print OUT "$base\t$tuplesize\t$tuplecounter\t$stcounter\t$st\t$mpval\t$topX\n";
			}			
		} #end state for
	} #end tuple for
	close(OUT);
} #end tuplesize for



