#!/usr/bin/perl
use strict;
use FindBin qw($Bin);

my $metalysis = "./bin/Metalysis";
my $shuffle = "utilities/shuffle-geneids.pl";
my $metalysisopts = "";

my $pvalsfile = $ARGV[0]; # data/GXM.txt
my $genelabelsfile = $ARGV[1]; # data/GXC.txt
$metalysisopts .= " " . $ARGV[2]; # "-nl0"
my $outdir = $ARGV[3]; # example_outputs/shuffled_outs
mkdir($outdir);
my $numsim = $ARGV[4]; # 10
my $startnum = $ARGV[5]; # 1
if (!defined($startnum)) { $startnum = 1; }

my $tmpid = rand();
my $tmpdir = "$outdir/shuffle_$tmpid";
mkdir($tmpdir);

for (my $i=$startnum; $i<($startnum+$numsim); $i++) {
    my $lfile = "$tmpdir/labels$i\.txt";
    Process("$shuffle $genelabelsfile > $lfile");
    Process("$metalysis $pvalsfile $lfile $metalysisopts > $outdir/sim$i\.txt 2> /dev/null");
}

sub Process {
    my $c = shift;
    warn "$c\n";
    system $c;
}
