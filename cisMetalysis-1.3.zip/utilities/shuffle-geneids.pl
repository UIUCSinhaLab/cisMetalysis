#!/usr/bin/perl
use strict;

my $infile = $ARGV[0];

open(I,"<$infile");
my $hdr = <I>;
my @names;
my @id2line;
my $i=0;
while (<I>) {
    chomp;
    my $line = $_;
    my ($name, @labels) = split("\t", $line);
    $id2line[$i] = join("\t",@labels);
    push @names, $name;
    $i++;
}
close(I);

my $len = $#names+1;
my @perm = RangePermutation($len);

print "$hdr";
for (my $i=0; $i < $len; $i++) {
    my $name = $names[$i];
    my $lineid = $perm[$i];
    print "$name\t".$id2line[$lineid]."\n";
}

sub RangePermutation {
    my $size = shift;
    my @permutation;
    for (my $i=0; $i<$size; $i++) { $permutation[$i] = $i; }
    for (my $i = $size-1; $i>=0; $i-- ) {
        my $j = int rand ($i+1);
        next if $i == $j;
        @permutation[$i,$j] = @permutation[$j,$i];
    }
    #warn join(",",@permutation)."\n";                                          
    return @permutation;
}
