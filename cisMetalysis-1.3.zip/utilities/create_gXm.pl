#!/usr/bin/perl
use strict;
use File::Basename;
use Getopt::Long;

my $windowsize = 500;
my $shiftsize  = 250;
my $fixedprobs = .0025;

GetOptions("win=i" => \$windowsize,
           "shift=i" => \$shiftsize,
			"fix=f" => \$fixedprobs);

my $gXcfile = $ARGV[0];
my $fafile = $ARGV[1];
my $wtmxfile = $ARGV[2];
my $stubbbin = $ARGV[3];
my $outfileprefix = $ARGV[4];

my $outprefix = basename($outfileprefix);
$outfileprefix =~ /(.+)$outprefix$/;
my $outdir = $1;
mkdir($outdir);

my $rid = rand();
my $tmpdir = "gXm.tmp.$rid";
system("rm -fr $tmpdir");
mkdir($tmpdir);
mkdir("$tmpdir/fa");
mkdir("$tmpdir/wtmx");
mkdir("$tmpdir/scans");

my %gXc_genes = ();
warn "Reading $gXcfile\n";
open (IN, "<$gXcfile") or die "Couldnt open $gXcfile\n";
my $gXc_header = "";
while (<IN>) {
	my $line = $_;
	chomp($line);
	if ($line =~ /^\t/) { $gXc_header = "$line\n"; next;}
	my ($gid, @rest) = split(/\t/,$line);
	$gXc_genes{$gid} = join("\t",@rest);
}
close(IN);
warn scalar(keys %gXc_genes)." gXc genes\n";

my %shared_genes = ();
warn "Reading $fafile\n";
open (IN, "<$fafile") or die "Couldnt open $fafile\n";
open (OUT, ">$tmpdir/fa/tmp.tmp");
while (<IN>) {
	my $line = $_;
	chomp($line);
	if ($line =~ /^>(.+)/) {
		my $gid = $1;
		if($gid eq ""){next;}
		if(defined($gXc_genes{$gid})){$shared_genes{$gid}=1;}
		close (OUT);
		open(OUT, ">$tmpdir/fa/$gid.fa") or die "Couldnt open tmpdir/fa/gid.fa";
		print OUT "$line\n";
	} else {
		print OUT "$line\n";
	}
}
close (OUT);
close(IN);
warn scalar(keys %shared_genes)." shared genes\n";

my %wtmxs; my %lengths;
warn "Reading $wtmxfile\n";
ReadWtmx(\%wtmxs, \%lengths, $wtmxfile);

system("echo \"0.0025\t0.9975\" > $tmpdir/fixedprobs.txt");

my @gids = sort keys %shared_genes;
my @wtmxlist = sort keys %wtmxs;

my %gXms = ();
foreach my $name (@wtmxlist) {
    
	warn("$name\n");
	## create a single pwm file
	open(OUT, ">$tmpdir/wtmx/$name\.wtmx");
	print OUT $wtmxs{$name};
	close(OUT);    

	my %gXws = ();
	foreach my $g (@gids){
		my $command = "$stubbbin $tmpdir/fa/$g.fa $tmpdir/wtmx/$name.wtmx $windowsize $shiftsize $tmpdir/fixedprobs.txt -od $tmpdir/scans/ -ft -1 -ot -1 ";
#		warn("$command\n");
		system("$command");
		open (IN, "<$tmpdir/scans/$g.fa.dict") or die "Couldnt open $tmpdir/scans/$g.fa.dict\n$command\n";
		while (<IN>) {
			my $line = $_;
			chomp($line);
			my ($win, $score) = split(/\t/,$line);
			$gXws{"$g:$win"} = $score;
		}
		close(IN);
	}
	my @sortedwindows = sort {$gXws{$b}<=>$gXws{$a}} keys %gXws;
	my $nwins = scalar(@sortedwindows);
	my %gXws = ();
	my $counter =0;
	for my $win (@sortedwindows){
		$counter++;
		my($g,$w) = split(":",$win);
		if(!defined($gXms{$g}{$name})){
			$gXms{$g}{$name} = int($counter/$nwins*10000)/10000;
		}
	}
}

open(OUT, ">$outfileprefix.gXc.txt") or die "Couldnt open $outfileprefix.gXc.txt";
print OUT $gXc_header;
for my $g (@gids){
	print OUT "$g\t".$gXc_genes{$g}."\n";
}
close(OUT);

open(OUT, ">$outfileprefix.gXm.txt") or die "Couldnt open $outfileprefix.gXm.txt";
print OUT "\t";
for my $w (@wtmxlist){
	print OUT "\t$w";
}
print OUT "\n";

for my $g (@gids){
	print OUT "$g";
	for my $w (@wtmxlist){
		my $val = 2;
		if(defined($gXms{$g}{$w})){ $val = $gXms{$g}{$w};}
		print OUT "\t$val";
	}
	print OUT "\n";
}
close(OUT);

system("rm -r $tmpdir/");

sub Process {
    my $c = shift;
    warn "$c\n";
    system $c;
}

sub ReadWtmx {
    my ($w, $l, $infile) = @_;
    open (IN, "<$infile") or die "Couldnt open $infile\n";
    
    my $motifname = undef;
    my $length = 0;
    my $x = '';
    while (<IN>) {
        my $line = $_;
        if ($line =~ /^</) {
            if (defined($motifname)) {
                $$w{$motifname} = $x;
                $$l{$motifname} = $length;
                $motifname = undef;
                $length = 0;
                $x = '';
            }
        }
        if ($line =~ /^>(\S+)\s+(\d+)/) {
            $motifname = $1;
            $length = $2;
            $x = $line;
            for (my $i=0; $i<$length; $i++) {
                my $line = <IN>;
                $x = $x . $line;
            }
            $x .= "<\n";
        }
    }
    close (IN);
    return;
}
