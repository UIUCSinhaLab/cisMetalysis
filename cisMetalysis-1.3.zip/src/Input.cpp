/*
 *  Input.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/17/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "CommonConstants.h" 
#include "Input.h"
#include <listop.h>

struct Genes *gns;
struct GenesXMotifs *gXm;
struct GenesXLabels *gXl;

int ReadGenesXMotifs(char *filename) 
// call this only once please
// return value is 0 if all went well
{
	if (gXm || gns) {
		fprintf(stderr,"Internal error: Function ReadGenesXMotifs called twice ?\n");
		exit(1);
	}
	
	gns = new struct Genes; // never freed
	gXm = new struct GenesXMotifs; // never freed
	
	char line[LINELENGTH+1];
	
	FILE *H = fopen(filename,"r");
	
	// first line is header, which has motif names
	// read these into a 1-D array
	// space allocated will be for (i) the entire string of the header line and (ii) array of pointers into 
	// this array, indicating motif name start poss
	fgets(line, LINELENGTH, H);
	Chomp(line);
	char *motifsline = new char[strlen(line)+1]; // never freed, since pointers to substrings within will be stored in gXm->motifs
	strcpy(motifsline, line);

	// this list is temporary, will be freed below
	list<char *> *motiflist = Split("\t",motifsline);
	
	gXm->numMotifs = 0;
	for (list<char *>::iterator it = motiflist->begin(); it != motiflist->end(); it++) {
		gXm->numMotifs++;
	}
	// put into an array
	gXm->motifs = new char *[gXm->numMotifs]; // never freed
	gXm->motifname2index = new unordered_map<const char *,int, my_hash, eqstr>; // never freed
		
	int i=0;
	for (list<char *>::iterator it = motiflist->begin(); it != motiflist->end(); it++) {
		char *motifname = (char *)(*it);
		gXm->motifs[i] = motifname;
		(*(gXm->motifname2index))[motifname] = i;
		i++;
	}
	
	// delete list object
	delete motiflist;
	
	// count #rows in file (remaining after header), then close and reopen the file
	gns->numGenes = 0;
	while (fgets(line, LINELENGTH, H)) {
		Chomp(line);
		if (strlen(line) < 0) break;
		gns->numGenes++;
	}
	fclose(H); H = fopen(filename, "r"); fgets(line, LINELENGTH, H);
	
	// read each line one by one, split into array of values (floats), and store
	gns->genes = new char *[gns->numGenes]; // never freed
	gXm->scores = new double *[gns->numGenes]; // never freed
	for (int c=0; c<gns->numGenes; c++) {
		gXm->scores[c] = new double[gXm->numMotifs]; // never freed
		for (int d=0; d<gXm->numMotifs; d++) {
			gXm->scores[c][d] = 0;
		}
	}
	i=0; // row (gene) index
	while (fgets(line, LINELENGTH, H)) {
		Chomp(line);
		char *running = line;
		char *token;

		// first col is gene name
		token = strsep(&running, "\t");
		gns->genes[i] = new char[strlen(token)+1]; // never freed
		strcpy(gns->genes[i],token);

		// remaining cols are scores
		int j = 0; // column (motif) index
		while (token = strsep(&running, "\t")) {
			double score = strtod(token, NULL);
			gXm->scores[i][j++] = score;
		}
		i++;
	}
	fclose(H);
	
#ifdef _DEBUG_1
	for (int c=0; c<gns->numGenes; c++) {
		for (int d=0; d<gXm->numMotifs; d++) {
			fprintf(stderr,"\t%.3f",gXm->scores[c][d]);
		}
		fprintf(stderr,"\n");
	}
#endif
	
	return 0;
}

int ReadGenesXLabels(char *filename) 
// call this only once please
// assume that ReadGenesXMotifs has been called and populated the "gns" Genes object.
// return value is 0 if all went well
{
	if (gXl) {
		fprintf(stderr,"Internal error: Function ReadGenesXLabels called twice ?\n");
		exit(1);
	}
	
	gXl = new struct GenesXLabels; // never freed
	
	char line[LINELENGTH+1];
	
	FILE *H = fopen(filename,"r");
	
	// first line is header, which has class names
	// read these into a 1-D array
	// space allocated will be for (i) the entire string of the header line and (ii) array of pointers into 
	// this array, indicating class name start poss
	fgets(line, LINELENGTH, H);
	Chomp(line);
	char *classline = new char[strlen(line)+1]; // never freed; pointers to substrings of this will be stored in gXl->classes[]
	strcpy(classline, line);
	
	// this list is temporary, will be freed below
	list<char *> *classlist = Split("\t",classline);
	
	gXl->numClasses = 0;
	for (list<char *>::iterator it = classlist->begin(); it != classlist->end(); it++) {
		gXl->numClasses++;
	}
	// put into an array
	gXl->classes = new char *[gXl->numClasses]; // never freed

	int i=0;
	for (list<char *>::iterator it = classlist->begin(); it != classlist->end(); it++) {
		char *classname = (char *)(*it);
		gXl->classes[i++] = classname;
	}

	// delete list object
	delete classlist;

	// count #rows in file (remaining after header), then close and reopen the file
	gns->numGenes = 0;
	while (fgets(line, LINELENGTH, H)) {
		Chomp(line);
		if (strlen(line) < 0) break;
		gns->numGenes++;
	}
	fclose(H); H = fopen(filename, "r"); fgets(line, LINELENGTH, H);
	
	// read each line one by one, split into array of values (ints), and store
	gXl->labels = new int *[gns->numGenes]; // never freed
	for (int c=0; c<gns->numGenes; c++) {
		gXl->labels[c] = new int[gXl->numClasses]; // never freed
		for (int d=0; d<gXl->numClasses; d++) {
			gXl->labels[c][d] = 0;
		}
	}
	i=0; // row (gene) index
	while (fgets(line, LINELENGTH, H)) {
		Chomp(line);
		char *running = line;
		char *token;
		
		// first col is gene name
		token = strsep(&running, "\t");
		if (strcmp(gns->genes[i],token)) { 
			printf("Error: genes in genesXmotifs file are not identical (and in same order) as in genesXlabels file\n");
			exit(1);
		}
		
		// remaining cols are labels
		int j = 0; // column (motif) index
		while (token = strsep(&running, "\t")) {
			int label = (int)strtol(token, NULL, 10);
			gXl->labels[i][j++] = label;
		}
		i++;
	}
	fclose(H);
#ifdef _DEBUG_1
	for (int c=0; c<gns->numGenes; c++) {
		for (int d=0; d<gXl->numClasses; d++) {
			fprintf(stderr,"\t%d",gXl->labels[c][d]);
		}
		fprintf(stderr,"\n");
	}
#endif
	return 0;
}

void ReadRedundantMotifPairs(char *filename)
{
	int numMotifs = gXm->numMotifs;
	gXm->isRedundantPair = new int *[numMotifs]; // never freed.
	for (int i=0; i<numMotifs; i++) {
		gXm->isRedundantPair[i] = new int[numMotifs]; // never freed
		for (int j=0; j<numMotifs; j++) {
			gXm->isRedundantPair[i][j] = 0;
			if (i==j) gXm->isRedundantPair[i][j] = 1;
		}
	}

	if (strlen(filename) == 0) { // no redundant file provided
	  return;
	}

	char line[LINELENGTH+1];
	FILE *H = fopen(filename,"r");
	while (fgets(line, LINELENGTH, H)) {
		Chomp(line);
		char *running = line;
		char *token;
		
		// first col is the "left" of the pair
		token = strsep(&running, "\t");
		if (gXm->motifname2index->find(token) == gXm->motifname2index->end()) {
			fprintf(stderr, "WARNING: redundant motif pairs includes motif %s, which is absent in genes X motifs file\n", token);
			continue;
		}
		int lIndex = (*gXm->motifname2index)[token];
		
		// remaining cols are labels
		while (token = strsep(&running, "\t")) {
			if (gXm->motifname2index->find(token) == gXm->motifname2index->end()) {
				fprintf(stderr, "WARNING: redundant motif pairs includes motif %s, which is absent in genes X motifs file\n", token);
				continue;
			}
			int rIndex = (*gXm->motifname2index)[token];
			gXm->isRedundantPair[lIndex][rIndex] = 1;
			gXm->isRedundantPair[rIndex][lIndex] = 1;
#ifdef _DEBUG_0
			fprintf(stderr,"Redundant motif pair: %d (%s) AND %d (%s)\n",lIndex, gXm->motifs[lIndex], rIndex, gXm->motifs[rIndex]);
#endif
		}
	}
	fclose(H);
	
}

void ReadMotifFilter(char *filename)
{
	int numMotifs = gXm->numMotifs;
	gXm->motifValid = new bool[numMotifs]; // never freed
	for (int i=0; i<numMotifs; i++) gXm->motifValid[i] = false;
	if (strlen(filename) == 0) { // no motif filter provided
	  for (int i=0; i<numMotifs; i++) gXm->motifValid[i] = true;
	  return;
	}

	char line[LINELENGTH+1];
	FILE *H = fopen(filename,"r");
	while (fgets(line, LINELENGTH, H)) {
		char motifname [1024];
		sscanf(line,"%s", &motifname);

		if (gXm->motifname2index->find(motifname) == gXm->motifname2index->end()) {
			fprintf(stderr, "WARNING: motif filter file includes motif %s, which is absent in genes X motifs file\n", motifname);
			continue;
		}
		int index = (*gXm->motifname2index)[motifname];
		gXm->motifValid[index] = true;
	}
	fclose(H);
	return;
}
		
