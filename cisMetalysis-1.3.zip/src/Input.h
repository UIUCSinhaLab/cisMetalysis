/*
 *  Input.h
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/17/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#ifndef _input_h_
#define _input_h_
#include <cstring>

#include <tr1/unordered_map>
using std::tr1::unordered_map;

struct eqstr
{
	inline bool operator()(const char* s1, const char* s2) const
{
    return strcmp(s1, s2) == 0;
}
};

struct my_hash {
  inline size_t operator()(const char* val) const
  {
    unsigned long h = 0;
    for (; *val; ++val)
      h = 5 * h + *val;
    return size_t(h);
  }
};

struct Genes {
	int numGenes;
	char **genes;
};

struct GenesXMotifs {
	int numMotifs;
	char **motifs;	
	unordered_map<const char *, int, my_hash, eqstr> *motifname2index;
	int **isRedundantPair;
	bool *motifValid;
	
	double **scores; // scores[i][j] is for gene index i and motif index j
};	
	
struct GenesXLabels {
	int numClasses;
	char **classes;	
	bool *classValid; // true for 1,-1,0
	
	int **labels; // labels[i][j] is for gene index i and class index j
};	

int ReadGenesXMotifs(char *filename); // read the matrix file into 
int ReadGenesXLabels(char *filename); // read the matrix file into 
void ReadRedundantMotifPairs(char *filename);
void ReadMotifFilter(char *filename);

#endif

