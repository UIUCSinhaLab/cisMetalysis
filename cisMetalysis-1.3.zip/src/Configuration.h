/*
 *  Configuration.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/18/09.
 *  Modified by Charles Blatti on 11/1/11.
 *  Copyright 2011 University of Illinois. All rights reserved.
 *
 */


#ifndef _config_h
#define _config_h

struct Configuration {
  double motifPvalThreshold;
  double associationPvalThreshold;
  int maxTupleSize;
  int maxTupleSizeForExhaustiveSearch;
  int topHowManyPerTupleSize;
  int minClassesToCombine;
  char *redundantmotifsfile;
  char *motiffilterfile;
  const char *mode;
  const char *pattern;
  const char *required;
  bool no_predicting_label0;
  bool no_motifabsencefeature;
  bool onelabelonly;
  bool no_tuple_subsets;
};

void Configure(int &argbase, int argc, char ** argv);

#endif

