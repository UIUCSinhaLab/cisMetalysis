/*
 *  SetManager.h
 *  Metalysis
 *
 *  Created by Saurabh Sinha on 6/18/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#ifndef _setmanager_h_
#define _setmanager_h_

struct Set {
	int cardinality; // NOT RELIABLE !!! (REMOVE THIS AT SOME POINT LATER)
	int size;
	int arraysize;
	unsigned char lastByteMask; // after complementing, need to reset the "irrelevant" bits in the last byte to 0
	unsigned char *bits; // array of bytes
	bool donotdelete;
};

void InitializeMotifSets(double scoreThreshold);
void InitializeExpressionSets();

Set *GetMotifSet(int index, int lt = 1); // lt = 0 means score > threshold // ALLOCATES SPACE
Set *GetExpressionSet(int index, int updown = 0);  // =0 means label = 1   // ALLOCATES SPACE
// updown = 1 would get those with label = -1; 
// updown = 2 would get label 0 
// updown = 3 would get any other label
Set *GetUniversalExpressionSet(int index); // ALLOCATES SPACE

void Union(Set *s1, Set *s2); // s1 will be modified
void Intersection(Set *s1, Set *s2); // s1 will be modified
void Complement(Set *s1); // s1 will be modified
Set *Copy(Set *s1);  // ALLOCATES SPACE
void Copy(Set *s2, Set *s1);
void Delete(Set *s1);

#endif

