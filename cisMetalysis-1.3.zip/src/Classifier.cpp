/*
 *  Configuration.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/18/09.
 *  Modified by Charles Blatti on 11/1/11.
 *  Copyright 2011 University of Illinois. All rights reserved.
 *
 */

#include "Classifier.h"
#include "SetManager.h"
#include "Stats.h"
#include "ProductPvalue.h"
#include "Storage.h"
#include <string>

static int compPvalues(const void * a,const void * b);
static DecisionForest **wdf;
static DecisionForest **bdf;

static int **consistent;
static double *pvalues;
static int *sortedindices;
static double *sortedpvalues;
static int *usedliterals;
static int *labelpattern;

void EnumerateMotifCombinations() 
{
  int numMotifs = gXm->numMotifs;
  int maxStates = GetNumStates(config->maxTupleSize, config->mode);

#ifdef _DEBUG_1  
  printf("Total number of states is %d and motifs is %d\n",maxStates, numMotifs);
#endif

  // various memory inits minClassesToCombine
  wdf = new DecisionForest *[gXl->numClasses]; // working decision forest
  for (int i=0; i<gXl->numClasses; i++) wdf[i] = new DecisionForest(maxStates, config->maxTupleSize);
  bdf = new DecisionForest *[gXl->numClasses]; // working decision forest
  for (int i=0; i<gXl->numClasses; i++) bdf[i] = new DecisionForest(maxStates, config->maxTupleSize);
  pvalues = new double[gXl->numClasses];
  sortedindices = new int[gXl->numClasses];
  sortedpvalues = new double[gXl->numClasses];

  labelpattern = new int[gXl->numClasses];
  int length = strlen(config->pattern);
  if(!strcmp(config->mode, "pattern")){
    if(length != gXl->numClasses) {
      printf("Pattern %s is not of length %d\n", config->pattern, gXl->numClasses);
      exit(1);
    }
    for (int i = 0; i<gXl->numClasses; i++){
      labelpattern[i] = 0;
      if(config->pattern[i]=='+')labelpattern[i]=1;
      if(config->pattern[i]=='-')labelpattern[i]=-1;
    }
#ifdef _DEBUG_1  
    for (int i = 0; i<gXl->numClasses; i++){
      printf("%d\t",labelpattern[i]);
    }
    printf("\n");
#endif
  }

  int rlength = strlen(config->required);
  if(strcmp(config->required, "")){
    if(rlength != gXl->numClasses) {
      printf("Required pattern %s is not of length %d\n", config->required, gXl->numClasses);
      exit(1);
    }
  }

  for (int tupleSize = 1; tupleSize <= config->maxTupleSizeForExhaustiveSearch; tupleSize++) {
    if (tupleSize > numMotifs) break;

    // find number of logics and states for this tuple size
    int numStates = GetNumStates(tupleSize, config->mode);
    int numBools = GetNumStates(tupleSize, "identical");

    consistent = new int*[numBools];
    for(int r=0; r<numBools;r++) {consistent[r] = new int[numStates];}
    
    int counter = 0;
    for(int r = 0; r<numBools; r++){
      for(int c = 0; c<numStates; c++){
        consistent[r][c] = counter;
        counter++;
      }
    }

    consistencyTable(consistent, tupleSize, numBools, numStates);

#ifdef _DEBUG_1  
    printf("mode: %s\n",config->mode);
    printf("Total number of states is %d\n",numStates);
    printf("Total number of logics is %d\n",numBools);
    for(int r = 0; r<numBools; r++){
      for(int c = 0; c<numStates; c++){
        printf("%d\t",consistent[r][c]);
      }
      printf("\n");
    }
#endif
    
    // enumerate all motif tuples of this size
    double bestCombinedPval = 1;
    usedliterals = new int[tupleSize];
    int *motifIndexArray = new int[tupleSize];
    for (int i=0; i<tupleSize; i++) motifIndexArray[i] = i;
    motifIndexArray[tupleSize-1]--; // so that when we get next tuple, we'll have the first tuple
    while (GetNextTuple(motifIndexArray, tupleSize)) {

#ifdef _DEBUG_1  
  PrintMotifTuple(motifIndexArray, tupleSize);
#endif

      // if tuple has redundant motifs, discard the tuple
      if (!ValidTuple(motifIndexArray, tupleSize)) continue;
#ifdef _DEBUG_1  
      PrintMotifTuple(motifIndexArray, tupleSize);
#endif
      
      double bestCombinedPvalForThisTuple = ProcessTuple(motifIndexArray, tupleSize, numStates, numBools);
      if (bestCombinedPvalForThisTuple < bestCombinedPval) bestCombinedPval = bestCombinedPvalForThisTuple;
      storage.Insert(motifIndexArray, tupleSize, bestCombinedPvalForThisTuple); // this will check if the solution is good enough to be inserted; if so, will copy over motifIndexArray
      
#ifdef _DEBUG_0 //keep
      printf("The best meta p-value of this tuple is %g\n\n\n",bestCombinedPvalForThisTuple);
#endif
    }
    delete [] motifIndexArray;
    delete [] usedliterals;
#ifdef _DEBUG_0 //keep
    printf("\n\nBEST meta p-value for tuple size %d is %g\n",tupleSize, bestCombinedPval);
#endif
    for (int i=0; i<numBools; i++) {
      delete consistent[i];
    }
    delete [] consistent;
  }
  
  
  for (int tupleSize = config->maxTupleSizeForExhaustiveSearch+1; tupleSize <= config->maxTupleSize; tupleSize++) {
    if (tupleSize > numMotifs) break;

    // find number of logics and states for this tuple size
    int numStates = GetNumStates(tupleSize, config->mode);
    int numBools = GetNumStates(tupleSize, "identical");

    consistent = new int*[numBools];
    for(int r=0; r<numBools;r++) {consistent[r] = new int[numStates];}
    
    int counter = 0;
    for(int r = 0; r<numBools; r++){
      for(int c = 0; c<numStates; c++){
        consistent[r][c] = counter;
        counter++;
      }
    }

    consistencyTable(consistent, tupleSize, numBools, numStates);

#ifdef _DEBUG_1  
    printf("mode: %s\n",config->mode);
    printf("Total number of states is %d\n",numStates);
    printf("Total number of logics is %d\n",numBools);
    for(int r = 0; r<numBools; r++){
      for(int c = 0; c<numStates; c++){
        printf("%d\t",consistent[r][c]);
      }
      printf("\n");
    }
#endif

    double bestCombinedPval = 1;
    usedliterals = new int[tupleSize];
    int *motifIndexArray = new int[tupleSize];

    int curSingletIndex = -1;
    while ((curSingletIndex = GetNextSinglet(curSingletIndex)) >= 0) {
      int curTupleIndex = 0;
      while (storage.ExtendTupleByOne(motifIndexArray, curTupleIndex, tupleSize-1, curSingletIndex)) {
        curTupleIndex++;
        if (!ValidTuple(motifIndexArray, tupleSize)) continue;
#ifdef _DEBUG_1  
        PrintMotifTuple(motifIndexArray, tupleSize);
#endif
        
        double bestCombinedPvalForThisTuple = ProcessTuple(motifIndexArray, tupleSize, numStates, numBools);
        if (bestCombinedPvalForThisTuple < bestCombinedPval) bestCombinedPval = bestCombinedPvalForThisTuple;
        storage.Insert(motifIndexArray, tupleSize, bestCombinedPvalForThisTuple); // this will check if the solution is good enough to be inserted; if so, will copy over motifIndexArray
        
#ifdef _DEBUG_0 //keep
        printf("This tuple has best meta p-value of %g\n\n\n",bestCombinedPvalForThisTuple);
#endif
      }
    }
    
    delete [] motifIndexArray;    
    delete [] usedliterals;
    for (int i=0; i<numBools; i++) {
      delete consistent[i];
    }
    delete [] consistent;

#ifdef _DEBUG_0 //keep
    printf("\n\nBEST meta p-value for tuple size %d is %g\n",tupleSize, bestCombinedPval);
#endif
  }

  delete [] labelpattern;
  delete [] sortedindices;
  delete [] sortedpvalues;
  delete [] pvalues;
  for (int i=0; i<gXl->numClasses; i++) {
    delete wdf[i];
    delete bdf[i];
  }
  delete [] wdf;
  delete [] bdf;
  
  return;
}

double ProcessTuple(int *motifIndexArray, int tupleSize, int numStates, int numBools)
{

  // enumerate all classes
  for (int c=0; c<gXl->numClasses; c++) { // for each class

#ifdef _DEBUG_1  
    printf("class %d: \n",c);  
#endif
    double bestClassPvalue = 1;
    bdf[c]->treesUsed = numStates;

    // update working decision forest
    for (int s=0; s<numStates; s++){
      bdf[c]->labels[s] = -1;
      bdf[c]->pvals[s] = 1.0;
    }
    for (int t=0; t<bdf[c]->numTrees; t++) bdf[c]->trees[t].depth=0;

    // store universe as "available"
    Set *available = GetUniversalExpressionSet(c);
    int availableSize = SetCardinality(available);
    if (availableSize <= 0){
      pvalues[c] = bestClassPvalue;
      continue;
    } 

    int maxLabel = 3;
    if(config->no_predicting_label0){maxLabel = 2;}

    int b = 0;  //number of the logical combination

    // enumerate all expression labels
    for (int l = 0; l < maxLabel; l++){  
    //l: 0-up regulated, 1-down regulated, 2-not regulated (i.e., label = 1,-1, 0)

#ifdef _DEBUG_1  
      printf("\tlabel %d: \n",l);  
#endif
    
      // get gene set G
      Set *G = GetExpressionSet(c, l);
      Intersection(G, available);
      Set *K = Copy(G);

      int *motifSubset = new int[tupleSize]; // array for track which motifs are in boolean formula
      //motifSubset[motif]: 0-motif excluded, 1-motif included
      for (int m=0; m<tupleSize; m++) { 
        if(config->no_tuple_subsets && m<tupleSize-1){motifSubset[m] = 1;}
        else {motifSubset[m] = 0;}
      }

      int *motifSign = new int[tupleSize]; // array for track the "sign" of motif set in boolean formula
      //motifSign[motif]: 0-negated motif set, 1-motif set, 2-motif excluded

      // enumerate all boolean subsets
      while(nextBoolTuple(motifSubset, tupleSize)){

        GetInitSign(motifSubset, motifSign, tupleSize);

        // enumerate all boolean literal signs
        while(nextMotifSign(motifSign, tupleSize)){

          if (config->no_motifabsencefeature){
            int flag = 0;  
            for (int m=0; m<tupleSize; m++) { 
              if(motifSign[m]==0){flag = 1;}  // skip if boolean contains negated literals
            }
            if(flag == 1){ continue; }
          }

#ifdef _DEBUG_1  
          PrintBoolean(tupleSize, motifSubset, motifSign);
#endif

          Set *B = Copy(available);
          for (int m=0; m<tupleSize; m++) { // find the set described by the boolean
            if(motifSign[m]==2){continue;}
            int newMotif = motifIndexArray[m];
            Set *M = GetMotifSet(newMotif, 1-motifSign[m]);
            Intersection(B, M);
            Delete(M);
          }

          Copy(K, G);
          Intersection(K, B);
          if(SetCardinality(K)==0){
#ifdef _DEBUG_1
            printf("none\n"); 
#endif
            b++;
            Delete(B);
            continue;
          }

          // get p-value
          int contable[4];
          double pval = ComputeEnrichmentPval(available, G, B, K, contable);
          if(pval<bestClassPvalue){bestClassPvalue=pval;}

#ifdef _DEBUG_1
          printf("%g     ",pval);
          printf("(");
          for (int i=0; i<4; i++) { printf("%d, ",contable[i]);}
          printf(")\n");
#endif

          // record this association if it is the best for each state
          for (int s=0; s<numStates; s++) {
            int flag = consistent[b][s];

            // flip the states if the pattern is '-' or allow both states if pattern is 0
            if(!strcmp(config->mode,"pattern")){
              if(labelpattern[c]==-1) flag = (flag-1)*-1;
              if(labelpattern[c]==0) flag = 1;
            }

            if(flag){

#ifdef _DEBUG_1
            printf("\t\t%d\t%d(%g) ",b,s, bdf[c]->pvals[s]);
#endif
              if (pval < bdf[c]->pvals[s]) { // record boolean
                int depth =0;
                for (int m=0; m<tupleSize; m++) { 
                  if (motifSign[m]==2){continue;} //motif excluded 
                  bdf[c]->trees[s].operators[depth] = 1;
                  int newliteral = motifIndexArray[m]+1;
                  if (motifSign[m]==0) {newliteral=newliteral*-1;}//motif negated 
                  bdf[c]->trees[s].motifindices[depth] = newliteral;
                  depth++;
                } 
                for (int ct=0; ct<4; ct++) bdf[c]->trees[s].contable[ct] = contable[ct];
                bdf[c]->trees[s].depth=depth;
                bdf[c]->pvals[s] = pval;
                bdf[c]->labels[s] = l;
#ifdef _DEBUG_1
                printf("+"); 
#endif
              }  // end best if
#ifdef _DEBUG_1
                printf("\n"); 
#endif
            }  // end consistent if
          }  // end state for
          
          b++;  // increment the boolean logic counter
          Delete(B);
        }  // end sign while
      }  // end subset while

      delete [] motifSign;
      delete [] motifSubset;
      Delete(G);
      Delete(K);
    }  //end expression label for

    pvalues[c] = bestClassPvalue;
    Delete(available);  
  }  // end classes for
  

#ifdef _DEBUG_0 //keep
  printf("\n\nEvaluating motif tuple, {");
  printf("M%d (%s)",motifIndexArray[0]+1,gXm->motifs[motifIndexArray[0]]);
  for (int i=1; i<tupleSize; i++) {
    printf(", M%d (%s)",motifIndexArray[i]+1,gXm->motifs[motifIndexArray[i]]);
  }
  printf("}\n");
  for (int c=0; c<gXl->numClasses; c++) {
    printf("%s\t%g\n",gXl->classes[c],pvalues[c]);
    if (bdf[c]->treesUsed > 0)
      bdf[c]->Print();
  }
#endif

  double bestCombinedPvalForThisTuple = 1;
  int bestToCombineState = 999;

  for (int s=0; s<numStates; s++){  // for each state of role configurations
    // copy state specific pvals to pvalues
    double minpval = 1;
    for (int c=0; c<gXl->numClasses; c++) { 
      pvalues[c] = bdf[c]->pvals[s];
      if(pvalues[c]<minpval) {minpval = pvalues[c];}
    }
    // initialize variables
    double bestCombinedPval = 1;
    int bestToCombineKClasses = 0;
    // for all k, multiply top k p-vals (top k classes) and compute its p-val; choose best such combined p-val
    for (int c=0; c<gXl->numClasses; c++) sortedindices[c] = c;
    qsort(sortedindices, gXl->numClasses, sizeof(int), compPvalues);

    int minRequired = 1; // find the minimum top k that contains all of the required conditions
    if(strcmp(config->required, "")){
      for (int k=1; k<=gXl->numClasses; k++) {   
        if(config->required[sortedindices[k-1]] == '1'){minRequired = k;}
      }
    }

    for (int k=1; k<=gXl->numClasses; k++) {        
      // store the combined p-val from previous step, along with complete description of classifer, for this tuple
      sortedpvalues[k-1] = pvalues[sortedindices[k-1]];
      if (sortedpvalues[k-1] > config->associationPvalThreshold) { 
#ifdef _DEBUG_1
        printf("Breaking after k=%d due to high p-value %g\n",k,sortedpvalues[k-1]); 
#endif
        break; 
      }
      if(strcmp(config->required, "") && k<minRequired){
#ifdef _DEBUG_1
        printf("Skip k=%d because top %d required\n",k,minRequired); 
#endif
        continue; 
      }

      double cpval = CombinePvaluesMaxK_DG(sortedpvalues, k, gXl->numClasses);
      if (cpval < 0) {
#ifdef _DEBUG_0 //keep
        fprintf(stderr,"Negative p-value returned; ignoring; %g\n",cpval);
#endif
        continue;
      }
#ifdef _DEBUG_1
      printf("Considering next best p-value: %g\t",pvalues[sortedindices[k-1]]);
      printf("This leads to combined p-value of %g\n",cpval);
#endif
      // if this tuple was better than the best seen so far, record/report that      
      if (cpval < bestCombinedPval && k >= config->minClassesToCombine) {
        bestCombinedPval = cpval;
        bestToCombineKClasses = k;
        if (bestCombinedPval < bestCombinedPvalForThisTuple) { 
          bestCombinedPvalForThisTuple = bestCombinedPval;
          bestToCombineState = s;
        }
      }
      if (cpval > 0.99) break;
    }  //end class for

#ifdef _DEBUG_0 //keep
	if(bestToCombineKClasses>0){ 
	    printf("Best to combine top %d from state %d with meta p-value of %g\n",bestToCombineKClasses, s, bestCombinedPval);
	}
#endif
  } //end state for 

  return bestCombinedPvalForThisTuple;
}
  

int compPvalues(const void * a,const void * b) 
{
  int ia = *((int *)a);
  int ib = *((int *)b);
  double *array = (double *)pvalues;
  if (array[ia] < array[ib]) return -1;
  else {
    if (array[ia] > array[ib]) return +1;
    else return 0;
  }
}

int GetNumStates(int tSize, const char *mode) 
{
  int nstates = 0;
  if(!strcmp(mode,"flexible")){nstates = 1;}
  if(!strcmp(mode,"pattern")){nstates = 2;}
  if(!strcmp(mode,"role")){nstates = (int)pow(2, tSize);}
  if(!strcmp(mode,"identical")){

    int maxLabel = 3;
    if(config->no_predicting_label0){maxLabel = 2;}

    // enumerate all expression labels
    for (int l = 0; l < maxLabel; l++){
    //l: 0-up regulated, 1-down regulated, 2-not regulated (i.e., label = 1,-1, 0)
//    printf("label:%d \n",l);
   
      int *motifSubset = new int[tSize]; // array for track which motifs are in boolean formula
      //motifSubset[motif]: 0-motif excluded, 1-motif included
      for (int m=0; m<tSize; m++) { 
        if(config->no_tuple_subsets && m<tSize-1){motifSubset[m] = 1;}
        else {motifSubset[m] = 0;}
      }
   
      int *motifSign = new int[tSize]; // array for track the "sign" of motif set in boolean formula
      //motifSign[motif]: 0-negated motif set, 1-motif set, 2-motif excluded

      while(nextBoolTuple(motifSubset, tSize)){

        GetInitSign(motifSubset, motifSign, tSize);

        // enumerate all boolean literal signs
        while(nextMotifSign(motifSign, tSize)){

          if (config->no_motifabsencefeature){
            int flag = 0;  
            for (int m=0; m<tSize; m++) { 
              if(motifSign[m]==0){flag = 1;}  // skip if boolean contains negated literals
            }
            if(flag == 1){ continue; }
          }
//        PrintBoolean(tSize, motifSubset, motifSign);
//        printf("\n"); 
          nstates++;
        }
      }
      delete [] motifSign;
      delete [] motifSubset;
    }
  }
  return nstates;
}
  
  
int GetNextSinglet(int curIndex) 
{
  int numMotifs = gXm->numMotifs;

  while (true) {
    curIndex++;
    if (curIndex >= numMotifs) return -1;
    if (gXm->motifValid[curIndex]) return curIndex;
  } 
}
    
bool GetNextTuple(int *array, int arraysize)
{
  bool success = false;
  
  int numMotifs = gXm->numMotifs;
  
  int curpos = arraysize-1;
  #ifdef _DEBUG_1
  printf("***motifs %d current %d\n",numMotifs, curpos);
  #endif

  // while it is not possible to increment curpos, decrement curpos
  while (!success) {
    array[curpos]++;
   #ifdef _DEBUG_1  
    PrintMotifTuple(array, arraysize);
   #endif
    if (array[curpos] >= numMotifs) {
      curpos--;
      if (curpos < 0) break;
    }
    else {
      for (int j=curpos+1; j<arraysize; j++) {
        array[j] = array[j-1]+1;
        if (array[j] >= numMotifs) return success;
      }
      success = true;
    }
  }
 return success;
}


bool GetInitSign(int *subsetArray, int *signArray, int arraysize)
{
  //subsetArray: 0-motif excluded, 1-motif included
  //signArray: 0-negated motif set, 1-motif set, 2-motif excluded

  bool success = false;
  int lastIncluded = -1;  
  for (int pos =0; pos<arraysize; pos++) {
    if(subsetArray[pos]==0){signArray[pos]=2;} //2 indicates not included
    if(subsetArray[pos]==1){
      signArray[pos]=0;
      lastIncluded = pos;
    }
  }
  return success;
}

bool nextMotifSign(int *array, int arraysize)
{
  //array: 0-negated motif set, 1-motif set, 2-motif excluded

  bool success = false;
  int curpos = arraysize-1;
  
  // while it is not possible to increment curpos, decrement curpos
  while (!success) {
    if(array[curpos]==2){curpos--;}
    if (curpos < 0) break;

    else{
      array[curpos]++;
      if (array[curpos] >= 2) {
        array[curpos]--;
        curpos--;
      }
      else {
        for (int j=curpos+1; j<arraysize; j++) {
          if(array[j]!=2){array[j]=0;}
        }
        success = true;
      }
    }
  }
  
  return success;
}

bool nextBoolTuple(int *array, int arraysize)
{
  //array: 0-motif excluded, 1-motif included

  bool success = false;
  int curpos = arraysize-1;
  
  // while it is not possible to increment curpos, decrement curpos
  while (!success) {
    array[curpos]++;
    if (array[curpos] >= 2) {
      curpos--;
      if (curpos < 0) break;
    }
    else {
      for (int j=curpos+1; j<arraysize; j++) {array[j] = 0;}
      success = true;
    }
  }
  
  return success;
}

void consistencyTable(int **consistent, int tSize, int numBools, int numStates){
  // 0 if boolean logic not consistent with state and 1 if is consistent
  if(!strcmp(config->mode,"flexible")){
    for(int r = 0; r<numBools; r++){
      for(int c = 0; c<numStates; c++){
        consistent[r][c]=1;
      }
    }
  }  
  if(!strcmp(config->mode,"identical")){
    for(int r = 0; r<numBools; r++){
      for(int c = 0; c<numStates; c++){
        consistent[r][c]=0;
        if(r == c){consistent[r][c]=1;}
      }
    }
  }
  if(!strcmp(config->mode,"pattern")){
   
    for(int r = 0; r<numBools; r++){
      for(int c = 0; c<numStates; c++){
        consistent[r][c]=0;
        if(r<numBools/2.0  && c==0){consistent[r][c]=1;}
        if(r>=numBools/2.0  && c==1){consistent[r][c]=1;}
      }
    }
  }
  if(!strcmp(config->mode,"role")){
 
    int b = 0;
    int maxLabel = 3;
    if(config->no_predicting_label0){maxLabel = 2;}

    // enumerate all expression labels
    for (int l = 0; l < maxLabel; l++){
    //l: 0-up regulated, 1-down regulated, 2-not regulated (i.e., label = 1,-1, 0)
//    printf("label:%d \n",l);
   
      int *motifSubset = new int[tSize]; // array for track which motifs are in boolean formula
      //motifSubset[motif]: 0-motif excluded, 1-motif included
      for (int m=0; m<tSize; m++) { 
        if(config->no_tuple_subsets && m<tSize-1){motifSubset[m] = 1;}
        else {motifSubset[m] = 0;}
      }
   
      int *motifSign = new int[tSize]; // array for track the "sign" of motif set in boolean formula
      //motifSign[motif]: 0-negated motif set, 1-motif set, 2-motif excluded

      while(nextBoolTuple(motifSubset, tSize)){

       GetInitSign(motifSubset, motifSign, tSize);

        // enumerate all boolean literal signs
        while(nextMotifSign(motifSign, tSize)){

          if (config->no_motifabsencefeature){
            int flag = 0;  
            for (int m=0; m<tSize; m++) { 
              if(motifSign[m]==0){flag = 1;}  // skip if boolean contains negated literals
            }
            if(flag == 1){ continue; }
          }
#ifdef _DEBUG_1
          PrintBoolean(tSize, motifSubset, motifSign);
          printf("\n"); 
#endif
          int *factorRole = new int[tSize]; // array for track which factors are activators and which are repressors
          //factorRole[factor_motif]: 0-factor activator, 1-factor repressor
          for (int m=0; m<tSize; m++) { factorRole[m] = 0;}
          factorRole[tSize-1] = -1;

          int roleState = 0; // role assignment of motif factor tuple, values between 0 and 2^n-1
          while(nextBoolTuple(factorRole, tSize)){
            consistent[b][roleState] = 0;
            if(consistencyCheck(factorRole, motifSign, l, tSize)){  consistent[b][roleState] = 1;}
            roleState++;
          }
          b++;
          delete [] factorRole;
        }
      }
      delete [] motifSign;
      delete [] motifSubset;
    }
  }

  return;
}


bool consistencyCheck(int *roleArray, int *signArray, int exprLabel, int arraysize){
  //roleArray[factor_motif]: 0-factor activator, 1-factor repressor
  //signArray[motif]: 0-negated motif set, 1-motif set, 2-motif excluded
  //exprLabel: 0-up regulated, 1-down regulated (i.e., label = 1,-1)

  bool consistent = true;

  for (int i=0; i<arraysize; i++) {
    if(signArray[i]==2){continue;}
    if(signArray[i]==exprLabel){  //factor should be repressor
      if(roleArray[i]==0){return false;}
    } else { //factor should be activator
      if(roleArray[i]==1){return false;}
    }
  }
  return consistent;
}


bool ValidTuple(int *array, int arraysize)
{
  for (int i=0; i<arraysize; i++) {
    if (!gXm->motifValid[array[i]]) return false;
    for (int j=i+1; j<arraysize; j++) {
      if (gXm->isRedundantPair[array[i]][array[j]]==1) {
        return false;
      }
    }
  }
  return true;
}

void PrintMotifTuple(int *motifIndexArray, int tupleSize)
{
  for (int i=0; i<tupleSize; i++) {
    printf("\t%d (%s)",motifIndexArray[i],gXm->motifs[motifIndexArray[i]]);
  }
  printf("\n");
}

void PrintBoolean(int tupleSize, int *motifSubset, int *motifSign)
{
  printf("\t\t(");
  for (int m=0; m<tupleSize; m++) { printf("%d, ",motifSubset[m]);}
  printf(")\t(");
  for (int m=0; m<tupleSize; m++) { printf("%d, ",motifSign[m]);}
  printf(")\t(");
  for (int m=0; m<tupleSize; m++) { 
    if(motifSign[m]==0){printf("~");}
    if(motifSubset[m]==1){printf("%d, ",m);}
    else{printf("-, ");}
  }
  printf(")\t");
}

Formula::Formula()
{
  maxdepth = 0;
  depth = 0;
}

void Formula::Initialize(int md)
{
  maxdepth = md;
  depth = 0;
  operators = new int[maxdepth];
  motifindices = new int[maxdepth];
}

Formula::~Formula()
{
  delete [] operators;
  delete [] motifindices;
}

void Formula::Copy(Formula *other)
{
  depth = other->depth;
#ifdef _DEBUG_1
  printf("Formula::Copy called for object of depth %d\n",depth);
#endif
  if (maxdepth != other->maxdepth) {
    printf("Internal error: copying formulas of unequal max depths\n");
    exit(1);
  }
  for (int i=0; i<depth; i++) {
#ifdef _DEBUG_1
    printf("copying op=%d\tmotifindex=%d\n",operators[i],motifindices[i]);
#endif
    operators[i] = other->operators[i];
    motifindices[i] = other->motifindices[i];
  }
  for (int i=0; i<4; i++) contable[i] = other->contable[i];
  return;
}

void Formula::Print()
{
  printf("\t%d", motifindices[0]);
  for (int i=1; i<depth; i++) printf("&%d",motifindices[i]);
  printf("\tct:");
  for (int i=0; i<4; i++) printf("\t%d",contable[i]);
}
  
DecisionForest::DecisionForest(int numlabels, int maxdepth)
{
  numTrees = numlabels;
  trees = new Formula[numTrees];
  for (int i=0; i<numTrees; i++) trees[i].Initialize(maxdepth);
  labels = new int[numTrees];
  pvals = new double[numTrees];
}

DecisionForest::~DecisionForest()
{
  delete [] trees;
  delete [] labels;
  delete [] pvals;
}

void DecisionForest::Copy(DecisionForest *other)
{
#ifdef _DEBUG_1
  printf("DecisionForest::Copy called\n");
#endif
  numTrees = other->numTrees;
  treesUsed = other->treesUsed;
  for (int i=0; i<numTrees; i++) {
    labels[i] = other->labels[i]; 
    pvals[i] = other->pvals[i]; 
    trees[i].Copy(&(other->trees[i]));
  }
}

void DecisionForest::Print()
{
#ifdef _DEBUG_1
  printf("Printing DecisionForest with %d trees used\n", treesUsed);
#endif
  for (int i=0; i<treesUsed; i++) {
   if (pvals[i] > config->associationPvalThreshold) {continue;} 

    if(labels[i]!=-1){
      int mylab = 2;
	if(labels[i]==0){mylab = 1;} 
 	if(labels[i]==1){mylab = -1;}
 	if(labels[i]==2){mylab = 0;}
     printf("%d:\t%d \t%g",i,mylab,pvals[i]);
          trees[i].Print();
          printf("\n");
            }
  }
}
