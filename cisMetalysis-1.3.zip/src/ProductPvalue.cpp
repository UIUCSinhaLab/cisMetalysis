/*
 *  ProductPvalue.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 9/20/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#include "ProductPvalue.h"
#include <gsl/gsl_errno.h>

static double ComputePvalueBestK(int n, int k, double tau);
static double pvalue_dettmanngeorgiou(int n, int k, double tau);
static double f (double t, void * params);
static double Choose (int n, int k);
static double Afun(double sigma_in, double a_in, int n_in);
static double factorial( int n );
static double F2(int k);
static double F1(int k);
static double Ftau(int k);

// implements the p-value of (1- \prod_i^k{1-p_i} of the k most significant
// p-values from a list of n p-values
// uses my own calculations as wrapper for 
// Orestis' code of Thm 1.

double CombinePvaluesMaxK_DG(double *pvals, int topk, int n)
{
	double u=1;
	for (int i=0; i<topk; i++) u *= (1-pvals[i]);
	u = 1-u;

	double pval = ComputePvalueBestK(n, topk, u);
	if (pval < 0) { return 0; } // Issue with numerical methods returning negative numbers for significant combos
	return pval;
}

double ComputePvalueBestK(int n, int k, double p)
// p is the observed val of (1- \prod_i^k{1-p_i}, in other words, this is \tau
{
//	fprintf(stderr,"ComputePvalueBestK called with n=%d k=%d p=%g\n",n,k,p);
	if (k == 1) {
		return 1-pow(1-p,n);
	}

	if (k == n) {
		double u=p;
		int size=n;
		double pval = 0;
		for (int i=0; i<size; i++) {
			double factor = 1;
			if (i%2 == 0) factor = 1; else factor = -1;
			for (int j = 1; j <= i; j++) factor *= log(1-u)/j;
			pval += factor;
		}
		pval *= (1-u);
		pval = 1-pval;
		
		return pval;
	}
#if 0
	if (k == n) {
		double pval = 1-Afun(1-p,1e-7,n);
		return pval;
	}
#endif
	double pval = pvalue_dettmanngeorgiou(n,k,p);
	// printf("%g\n",pval);
	return pval;
}

double pvalue_dettmanngeorgiou(int n, int k, double tau)
{
	// case: 1 < k < n
	
  gsl_error_handler_t * old_handler=gsl_set_error_handler_off();
  //switch off default error handler, store old error handler in
  //old_handler

	gsl_integration_workspace * w 
    = gsl_integration_workspace_alloc (1000);
	
	double lowval = 0;
	double highval = 1;
	
	double params[3];
	params[0] = n;
	params[1] = k;
	params[2] = 1-tau;
	
	double result, error;
	gsl_function F;
	F.function = &f;
	F.params = &params;
	
	double relerr = 1e-7;
	int status;
	while (relerr < 0.01) {
	  status = gsl_integration_qags (&F, lowval, highval, 0, relerr, 1000,
						  w, &result, &error); 
	  relerr *= 10;
	  if (!status) break; else fprintf(stderr,"Increased relerr to %g\n", relerr);
	}
	
	double pval = result * Choose(n, k+1) * (k+1);
	pval = 1 - pval;
	gsl_integration_workspace_free (w);

	// printf("ComputePvalue Returning pval = %g\n",pval);
	gsl_set_error_handler(old_handler); //reset error handler (might be unneccessary.

	if (status) { fprintf(stderr,"Warning: integration did not converge. Returning pval=1\n"); return 1; }
	
	return pval;
}

double f (double t, void * params) {
	double *paramlist = (double *)params;
	int n = int(paramlist[0]);
	int k = int(paramlist[1]);
	double oneminustau = paramlist[2];
	
	double retval = pow(t, n-k-1) * pow(1-t,k) * Afun(oneminustau, t, k);
	// printf("f(%d, %d, %g, %g) Returning %g\n",n,k,oneminustau,t,retval);
	return retval;
}


double Choose (int n, int k)
{
	if (k > n || k < 0) return 0;
	if (k == n || k == 0) return 1;
	
	double val = 1;
	for (int i=1; i<=(n-k); i++) {
		val *= double(k+i)/double(i);
	}
	return val;
}

////////////////////////////////////////////////////////////
// The following code is by Orestis Georgiou, 25-8-09,
// with cosmetic changes by SS
// OG's code works through globals
// This program is related to the paper: Product of n independent Uniform Random Variables.
//
// When Theorem 1. of the above paper is integrated, the incomplete gamma function, Gamma[n,x]
// is obtained which for integer n can be expressed analytically. Thus, this program calculates 
// the probability that a random variable X, consisting of the product of n independent and
// identically distributed uniform [a, b] random variables X_{i}, i=1,2..n, takes on a value
// less than or equal to tau.
//

static int n;
static double a,b,tau;
static int j, m;
static double Prob, diff, OutPut, A;
#define alpha(k) (pow(a,(n-k+1))* pow(b,(k-1)))
#define beta(k) ( pow(a,(n-k))* pow(b,k))

double Afun(double sigma_in, double a_in, int n_in)
// given n variables that are uniform on [a,1], pr that their product
// is less than sigma
{
	if (pow(a_in,n_in) >= sigma_in) {
		// printf("Afun(sigma=%g a=%g n=%d) returning 0\n", sigma_in, a_in, n_in);
		return 0;
	}
	
	b = 1; 
	tau = sigma_in;
	a = a_in;
	n = n_in;
	
	int k=1;
	
	Prob = 0.00;
	while ( tau > beta(k)) {            
		diff= F2(k)-F1(k);
		Prob= Prob + diff;
		k=k+1;       
	}
	Prob+= Ftau(k) - F1(k);
		
	// printf("Afun(sigma=%g a=%g n=%d) returning %g\n",tau, a, n, Prob);
	return Prob;
}

// define the factorial function
double factorial( int n )
{
	double fact = 1;   
	while ( n > 1) {
		fact = fact * n;
    n = n - 1;   }
	return fact;
}

// define the F2 function
double F2(int k)
{
	for(j=0,OutPut=0;j<(n-k+1);j++)
    {
		for(m=1,A=0;m<n;m++)
		{A+= pow(log( (pow(a,j)*pow(b,n-j))/beta(k) ), m) / factorial(m);}
		OutPut+= beta(k)*factorial(n-1)*(1+A)*n* pow((-1),j)/(factorial(j)*factorial(n-j)* pow((b-a),n)) ;
    }
	return OutPut;
}

// define the F1 function
double F1(int k)
{
	for(j=0,OutPut=0;j<n-k+1;j++)
    {
		for(m=1,A=0;m<n;m++)
		{A+= pow(log( (pow(a,j)*pow(b,n-j))/alpha(k) ), m) / factorial(m);}
		OutPut+= alpha(k) *factorial(n-1)*(1+A)*n* pow((-1),j)/(factorial(j)*factorial(n-j)* pow((b-a),n)) ;
    }
	return OutPut;
}

// define the Ftau function
double Ftau(int k)
{
	for(j=0,OutPut=0;j<n-k+1;j++)
    {
		for(m=1,A=0;m<n;m++)
		{A+= pow(log( (pow(a,j)*pow(b,n-j))/tau ), m) / factorial(m);}
		OutPut+= tau*factorial(n-1)*(1+A)*n* pow((-1),j)/(factorial(j)*factorial(n-j)* pow((b-a),n)) ;
    }
	return OutPut;
}
