/*
 *  CommonConstants.h
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/17/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#ifndef _commonconstants_h_
#define _commonconstants_h_

#define LINELENGTH 100000
#define BYTESIZE 8
#define LOGBYTESIZE 3
#endif

