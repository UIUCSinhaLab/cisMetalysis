/*
 *  SetManager.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha on 6/18/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "SetManager.h"
#include "CommonConstants.h"
#include "Input.h"
#include "Stats.h"

extern struct Genes *gns; // will be allocated by the Reading function
extern struct GenesXMotifs *gXm; // will be allocated by the Reading function
extern struct GenesXLabels *gXl; // will be allocated by the Reading function

Set **ExpressionSets;  // indices 0,1,2,3 for labels 1,-1,0,other respectively 
Set **MotifSets; // indices 0 and 1 for score > threshold and score <= threshold respecively

// functions that allocate space for sets are:
// InitializeMotifSets
// InitializeExpressionSets
// GetMotifSet
// GetExpressionSet
// GetUniversalExpressionSet
// Set *Copy(Set *s1)

void InitializeMotifSets(double scoreThreshold)
{
	MotifSets = new Set *[2]; // never freed
	int numMotifs = gXm->numMotifs;
	int numGenes = gns->numGenes;
	int numBytes = int(numGenes/BYTESIZE);
	if (numBytes*BYTESIZE < numGenes) numBytes++;

	for (int i=0; i<2; i++) {
		MotifSets[i] = new Set[numMotifs];	// never freed
		for (int j=0; j<numMotifs; j++) {
			// first initialize set
			MotifSets[i][j].size = numGenes;
			MotifSets[i][j].arraysize = numBytes;
			MotifSets[i][j].bits = new unsigned char[numBytes]; // should never be freed (see next line)
			MotifSets[i][j].donotdelete = true;
			unsigned int geneIndex = 0;
			int cardinality = 0;
			for (int k=0; k<numBytes; k++) {
				MotifSets[i][j].bits[k] = 0;
				int l=0;
				for (; l<BYTESIZE; l++) {
					if (geneIndex >= numGenes) break;
					unsigned int byteIndex = geneIndex>>LOGBYTESIZE;
					unsigned int bitIndex = geneIndex&((1<<LOGBYTESIZE)-1);
					bool belongs = (i==0 ? gXm->scores[geneIndex][j] <= scoreThreshold : gXm->scores[geneIndex][j] > scoreThreshold);
					if (belongs) {
						MotifSets[i][j].bits[byteIndex] |= (1<<(BYTESIZE-1-bitIndex));
						cardinality++;
					}
					geneIndex++;
				}
				if (k==numBytes-1) { // this is the last byte; the last byte has BYTESIZE-l irrelevant bits
					MotifSets[i][j].lastByteMask = (unsigned char)(((1 << BYTESIZE)-1) << (BYTESIZE-l));
				}					
				if (geneIndex >= numGenes) break;
			}
			MotifSets[i][j].cardinality = cardinality;
		}
	}		
}

void InitializeExpressionSets()
{
	ExpressionSets = new Set *[4]; // 0 is for +1, 1 is for -1, 2 is for 0 and 3 is for other // never freed
	int numClasses = gXl->numClasses;
	int numGenes = gns->numGenes;
	int numBytes = int(numGenes/BYTESIZE);
	if (numBytes*BYTESIZE < numGenes) numBytes++;
	for (int i=0; i<4; i++) { // each i is for a possible value of label
		ExpressionSets[i] = new Set[numClasses]; // never freed
		for (int j=0; j<numClasses; j++) {
			// first initialize set
			ExpressionSets[i][j].size = numGenes;
			ExpressionSets[i][j].arraysize = numBytes;
			ExpressionSets[i][j].bits = new unsigned char[numBytes]; // should never be freed, see next line
			ExpressionSets[i][j].donotdelete = true;
			unsigned int geneIndex = 0;
			int cardinality = 0;
			for (int k=0; k<numBytes; k++) {
				ExpressionSets[i][j].bits[k] = 0;
				int l=0;
				for (; l<BYTESIZE; l++) {
					if (geneIndex >= numGenes) break;
					unsigned int byteIndex = geneIndex>>LOGBYTESIZE;
					unsigned int bitIndex = geneIndex&((1<<LOGBYTESIZE)-1);
					int label = gXl->labels[geneIndex][j];
					bool belongs = (label == 1 ? i == 0 : (label == -1 ? i==1 : (label == 0 ? i==2 : (i == 3))));
					if (belongs) {
						ExpressionSets[i][j].bits[byteIndex] |= (1<<(BYTESIZE-1-bitIndex));
						cardinality++;
					}
					geneIndex++;
				}
				if (k==numBytes-1) { // this is the last byte; the last byte has BYTESIZE-l irrelevant bits
					ExpressionSets[i][j].lastByteMask = (unsigned char)(((1 << BYTESIZE)-1) << (BYTESIZE-l));
				}					
				if (geneIndex >= numGenes) break;
			}
			ExpressionSets[i][j].cardinality = cardinality;
		}
	}	
}

Set *GetMotifSet(int motifIndex, int lt) 
// lt = 0 means score > threshold
// create a copy, since this may be modified
{
	int ind = lt;
	Set *set = new Set;
	Set *oset = &(MotifSets[ind][motifIndex]);
	set->size = oset->size;
	set->arraysize = oset->arraysize;
	set->cardinality = oset->cardinality;
	set->lastByteMask = oset->lastByteMask;
	set->bits = new unsigned char[oset->arraysize];
	for (int i=0; i<oset->arraysize; i++) {
		set->bits[i] = oset->bits[i];
	}
	set->donotdelete = false;
	return set;
}

Set *GetExpressionSet(int classIndex, int updown) 
// create a copy
{
	int ind = updown;
	Set *set = new Set;
	Set *oset = &(ExpressionSets[ind][classIndex]);
	set->size = oset->size;
	set->arraysize = oset->arraysize;
	set->cardinality = oset->cardinality;
	set->lastByteMask = oset->lastByteMask;
	set->bits = new unsigned char[oset->arraysize];
	for (int i=0; i<oset->arraysize; i++) {
		set->bits[i] = oset->bits[i];
	}
	set->donotdelete = false;
	return set;
}

Set *GetUniversalExpressionSet(int index)
{
	Set *set = GetExpressionSet(index, 3); // get all genes with invalid class labels (not 1,-1,0)
	Complement(set);
	return set;
}
	
void Delete(Set *s1)
{
	if (s1->donotdelete) {
		fprintf(stderr,"Internal error: call for deleting set that shouldnt be deleted\n");
		exit(1);
	}
	delete [] s1->bits;
	delete s1;
}

void Union(Set *s1, Set *s2) // s1 will be modified
{
	if (s1->arraysize != s2->arraysize) {
		fprintf(stderr, "Internal error: Union called on incompatible set structures\n");
		exit(1);
	}
	for (int i=0; i<s1->arraysize; i++) {
		s1->bits[i] |= s2->bits[i];
	}
	return;
}

void Intersection(Set *s1, Set *s2) // s1 will be modified
{
	if (s1->arraysize != s2->arraysize) {
		fprintf(stderr, "Internal error: Union called on incompatible set structures\n");
		exit(1);
	}
	for (int i=0; i<s1->arraysize; i++) {
		s1->bits[i] &= s2->bits[i];
	}
	return;
}

void Complement(Set *s1)
{
	for (int i=0; i<s1->arraysize; i++) {
		s1->bits[i] = ~(s1->bits[i]);
	}
	s1->bits[s1->arraysize-1] &= s1->lastByteMask;
	s1->cardinality = s1->size - s1->cardinality;
	return;
}

Set *Copy(Set *s1)
{
	Set *s2 = new Set;
	s2->size = s1->size;
	s2->arraysize = s1->arraysize;
	s2->cardinality = s1->cardinality;
	s2->lastByteMask = s1->lastByteMask;
	s2->bits = new unsigned char[s1->arraysize];
	for (int i=0; i<s1->arraysize; i++) {
		s2->bits[i] = s1->bits[i];
	}
	s2->donotdelete = false;
	return s2;
}

void Copy(Set *s2, Set *s1) 
{
	if (s2->arraysize != s1->arraysize) {
		fprintf(stderr, "Internal error: cannot copy a set onto another if universe sizes are different\n");
		exit(1);
	}
	s2->size = s1->size;
	s2->arraysize = s1->arraysize;
	s2->cardinality = s1->cardinality;
	s2->lastByteMask = s1->lastByteMask;	
	for (int i=0; i<s1->arraysize; i++) {
		s2->bits[i] = s1->bits[i];
	}
	return;
}
