/*
 *  Configuration.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/18/09.
 *  Modified by Charles Blatti on 11/1/11.
 *  Copyright 2011 University of Illinois. All rights reserved.
 *
 */

#include "Configuration.h"
#include <cstring>
#include <stdio.h>
#include <stdlib.h>

struct Configuration *config;

void Configure(int &argbase, int argc, char **argv) 
{
  config = new Configuration;

  config->redundantmotifsfile = new char[1024];  // -r
  config->redundantmotifsfile[0] = 0;
  config->motiffilterfile = new char[1024];  // -f
  config->motiffilterfile[0] = 0; 

  config->associationPvalThreshold = 0.05; // -apt
  config->mode = "flexible";  // -m
  config->pattern = "";  // -p
  config->required = "";  //-req
  config->topHowManyPerTupleSize = 500; 
  config->maxTupleSizeForExhaustiveSearch = 2;   

  config->motifPvalThreshold = 0.01;  // -mtp
  config->minClassesToCombine = 1;  // -mincl
  config->maxTupleSize = 2; // -mts  
  config->no_predicting_label0 = false;  // -nl0
  config->no_motifabsencefeature = false;  // -nmaf
  config->no_tuple_subsets = false;  // -nts

  config->onelabelonly = false;  // -olo

  // read optional arguments
  while (argbase < argc && argv[argbase][0]=='-') {
//    printf("%d %d %s\n",argbase,  argc, argv[argbase]);
    if (!strcmp(argv[argbase],"-r")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -r must be followed by a file path for redundant motif file\n");
	exit(1);
      }
      strcpy(config->redundantmotifsfile, argv[argbase]);
      argbase++;
      continue;
    }
    if (!strcmp(argv[argbase],"-f")) {
      argbase++;
      if (argbase >= argc) {
	fprintf(stderr,"Error: -f must be followed by a file path for motif filter\n");
	exit(1);
      }
      strcpy(config->motiffilterfile, argv[argbase]);
      argbase++;
      continue;
    }

    if (!strcmp(argv[argbase],"-m")) {
      argbase++;
      if (argbase>=argc) {
	printf("Error: -m must be followed by a valid mode [flexible, role, identical, pattern]\n");
	exit(1);
      }
      char *modeStr = argv[argbase];
      bool validMode = 0;
      if(!strcmp(modeStr, "flexible")){validMode = 1;}
      if(!strcmp(modeStr, "role")){validMode = 1;}
      if(!strcmp(modeStr, "identical")){validMode = 1;}
      if(!strcmp(modeStr, "pattern")){validMode = 1;}
      if (!validMode) {
	printf("Error: -m must be followed by a valid mode [flexible, role, identical, pattern]\n");
	exit(1);
      }
      config->mode = modeStr;
      argbase++;
      continue;
    }   
    if (!strcmp(argv[argbase],"-p")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -p must be followed by a combination of +'s, -'s, and 0's for condition pattern.\n");
	exit(1);
      }
      char *patternStr = argv[argbase];
      int length = strlen(patternStr);
      bool flag = 0;
      for (int i = 0; i<length; i++){
        if(!(patternStr[i] == '+' || patternStr[i] == '-' || patternStr[i] == '0')) flag = 1;
      }
      if (flag) {
	printf("Error: -p must be followed by a combination of +'s, -'s, and 0's for condition pattern.\n");
	exit(1);
      }
      config->pattern = patternStr;
      argbase++;
      continue;
    }   
    if (!strcmp(argv[argbase],"-req")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -req must be followed by a combination of 0's, 1's for required conditions\n");
	exit(1);
      }
      char *patternStr = argv[argbase];
      int length = strlen(patternStr);
      bool flag = 0;
      for (int i = 0; i<length; i++){
        if(!(patternStr[i] == '0' || patternStr[i] == '1')) flag = 1;
      }
      if (flag) {
	printf("Error: -req must be followed by a combination of 0's, 1's for required conditions\n");
	exit(1);
      }
      config->required = patternStr;
      argbase++;
      continue;
    }   
    if (!strcmp(argv[argbase],"-mincl")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -mincl must be followed by positive integer for minimum conditions to combine\n");
	exit(1);
      }
      config->minClassesToCombine = atoi(argv[argbase]);
      argbase++;
      continue;
    }   
    if (!strcmp(argv[argbase],"-mts")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -mts must be followed by positive integer for maximum tuple size\n");
	exit(1);
      }
      config->maxTupleSize = atoi(argv[argbase]);
      if(config->maxTupleSize < config->maxTupleSizeForExhaustiveSearch){
        config->maxTupleSizeForExhaustiveSearch=config->maxTupleSize;
      }
      argbase++;
      continue;
    }
    if (!strcmp(argv[argbase],"-mtp")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -mtp must be followed by number for motif pvalue threshold\n");
	exit(1);
      }
      config->motifPvalThreshold = atof(argv[argbase]);
      argbase++;
      continue;
    }   
    if (!strcmp(argv[argbase],"-apt")) {
      argbase++;
      if (argbase >= argc) {
	printf("Error: -apt must be followed by number for association pvalue threshold\n");
	exit(1);
      }
      config->associationPvalThreshold = atof(argv[argbase]);
      argbase++;
      continue;
    }   

    // boolean options
    if (!strcmp(argv[argbase],"-nl0")) {
      config->no_predicting_label0 = true;
      argbase++;
      continue;
    }
    if (!strcmp(argv[argbase],"-nmaf")) {
      config->no_motifabsencefeature = true;
      argbase++;
      continue;
    }
    if (!strcmp(argv[argbase],"-olo")) {
      config->onelabelonly = true;
      argbase++;
      continue;
    }   
    if (!strcmp(argv[argbase],"-nts")) {
      config->no_tuple_subsets = true;
      argbase++;
      continue;
    }

    printf("Error: %s not a valid option\n", argv[argbase]);
    exit(1);
  }
}
