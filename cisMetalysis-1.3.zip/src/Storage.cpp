/*
 *  Storage.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 7/6/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "Storage.h"

struct Storage storage;

void Storage::Initialize(int mTS, int tHMPTS) 
{
	maxTupleSize = mTS;
	topHowManyPerTupleSize = tHMPTS;
	tuples = new int **[maxTupleSize]; // each index i will store a list of top tuples of size i+1
	scores = new double *[maxTupleSize];
	worstScores = new double[maxTupleSize];
	worstScoreIndex = new int[maxTupleSize];
	sizeOfStorage = new int[maxTupleSize];
	for (int i=0; i<maxTupleSize; i++) {
		tuples[i] = new int *[topHowManyPerTupleSize];
		scores[i] = new double[topHowManyPerTupleSize];
		worstScores[i] = 0;
		worstScoreIndex[i] = 0;
		sizeOfStorage[i] = 0;
		for (int j=0; j<topHowManyPerTupleSize; j++) {
			tuples[i][j] = new int[i+1];
			for (int k=0; k<i+1; k++) tuples[i][j][k] = -1;
			scores[i][j] = 1;
		}
	}
	return;
}
	
void Storage::Insert(int *motifIndexArray, int tupleSize, double score)
{
	if (tupleSize > maxTupleSize) {
		fprintf(stderr, "Internal error: tupleSize %d > maxTupleSize %d\n",tupleSize, maxTupleSize);
		exit(1);
	}


	if (sizeOfStorage[tupleSize-1] == topHowManyPerTupleSize) {
		if (score > worstScores[tupleSize-1]) return;
				
		for (int i=0; i<tupleSize; i++) tuples[tupleSize-1][worstScoreIndex[tupleSize-1]][i] = motifIndexArray[i];
		scores[tupleSize-1][worstScoreIndex[tupleSize-1]] = score;

		// update the worstScores array
		double worstScore = 0;
		int wSI = 0;
		for (int j=0; j<topHowManyPerTupleSize; j++) {
			if (scores[tupleSize-1][j] > worstScore) {
				worstScore = scores[tupleSize-1][j];
				wSI = j;
			}
		}
		worstScores[tupleSize-1] = worstScore;
		worstScoreIndex[tupleSize-1] = wSI;
		
		return;
	}
	
	// next position that is not initialized
	int wSI = sizeOfStorage[tupleSize-1];
	for (int i=0; i<tupleSize; i++) tuples[tupleSize-1][wSI][i] = motifIndexArray[i];
	scores[tupleSize-1][wSI] = score;
	sizeOfStorage[tupleSize-1] ++;

	if (sizeOfStorage[tupleSize-1] == topHowManyPerTupleSize) { // then update worst score and its index
		double worstScore = 0;
		int wSI = 0;
		for (int j=0; j<topHowManyPerTupleSize; j++) {
			if (scores[tupleSize-1][j] > worstScore) {
				worstScore = scores[tupleSize-1][j];
				wSI = j;
			}
		}
		worstScores[tupleSize-1] = worstScore;
		worstScoreIndex[tupleSize-1] = wSI;
	}
	
	return;
}
	
bool Storage::ExtendTupleByOne(int *motifIndexArray, int curTupleIndex, int tupleSizeMinusOne, int curSingletIndex)
{
	if (tupleSizeMinusOne < 1 || tupleSizeMinusOne > maxTupleSize || curTupleIndex < 0 || curTupleIndex >= sizeOfStorage[tupleSizeMinusOne-1]) return false;
	for (int i=0; i<tupleSizeMinusOne; i++) motifIndexArray[i] = tuples[tupleSizeMinusOne-1][curTupleIndex][i];
	motifIndexArray[tupleSizeMinusOne] = curSingletIndex;
	return true;
}

