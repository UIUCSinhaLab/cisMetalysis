/*
 *  ProductPvalue.h
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 9/20/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_integration.h>

double CombinePvaluesMaxK_DG(double *pvals, int topk, int n);

