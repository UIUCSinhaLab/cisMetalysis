/*
 *  Stats.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/20/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#include <stdio.h>
#include <math.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_integration.h>
#include "Stats.h"

double ComputeEnrichmentPval(Set *U, Set *G, Set *M, Set *K, int *contable)
{
	int u = SetCardinality(U);
	int g = SetCardinality(G);
	int m = SetCardinality(M);
	int k = SetCardinality(K);
	contable[0] = u;
	contable[1] = g;
	contable[2] = m;
	contable[3] = k;
	double pval = 0;
	int minsize = (g<m?g:m);
	for (int i=k; i<=minsize; i++) pval += gsl_ran_hypergeometric_pdf(i,g,u-g,m);
#ifdef _DEBUG_1	
	printf("Enrichment test with %d %d %d %d: pval = %g\n",u,g,m,k,pval);
#endif
	return pval;
}

double CombinePvalues(double *pvals, int size) 
{
	double u=1;
	for (int i=0; i<size; i++) u *= (1-pvals[i]);
	u = 1-u; 
	if (u==1) return 1;
	
	double pval = 0;
	for (int i=0; i<size; i++) {
		double factor = 1;
		if (i%2 == 0) factor = 1; else factor = -1;
		for (int j = 1; j <= i; j++) factor *= log(1-u)/j;
		pval += factor;
	}
	pval *= (1-u);
	pval = 1-pval;
	
	return pval;
}

double CombinePvaluesMaxK(double *pvals, int topk, int n)
{
	double u=1;
	for (int i=0; i<topk; i++) u *= pvals[i];
	
	double p = u;
	int k = topk;

	if (k == 1) {
		return 1-pow(1-p,n);
	}
	
	if (k == n) {
		int size=n;
		double pval = 0;
		for (int i=0; i<size; i++) {
			double factor = 1;
			if (i%2 == 0) factor = 1; else factor = -1;
			for (int j = 1; j <= i; j++) factor *= log(u)/j;
			pval += factor;
		}
		pval *= u;
		
		return pval;
	}
	
	// case: 1 < k < n
	
	gsl_integration_workspace * w 
    = gsl_integration_workspace_alloc (1000);
 
	double lowval = 0;
	double highval = 1;
	
	double params[3];
	params[0] = n;
	params[1] = k;
	params[2] = p;
	
	double result, error;
	gsl_function F;
	F.function = &f;
	F.params = &params;
	
	gsl_integration_qags (&F, lowval, highval, 0, 1e-7, 1000,
						  w, &result, &error); 
	
	
	result *= Choose(n,k+1)*(k+1);
	
	gsl_integration_workspace_free (w);
	
	return result;
	// return CombinePvalues(pvals, topk);
}


double f (double x, void * params) {
	double *paramlist = (double *)params;
	int n = int(paramlist[0]);
	int k = int(paramlist[1]);
	double p = paramlist[2];
	
	double f = pow((1-x), (n-k-1));
	
	if (pow(x,k) <= p) return f * pow(x,k);
	
	//  f *= pow(x, k-1);
	double sum = 1;
	for (int j=1; j <= k-1; j++) {
		double term = pow((k*log(x)-log(p)),j);
		for (int l=1; l<=j; l++) term /= l;
		sum += term;
	}
	f *= sum * p;
	
	// printf("x = %g n = %d k = %d p = %g f = %g\n",x,n,k,p,f);
	return f;
}

double Choose (int n, int k)
{
	if (k > n || k < 0) return 0;
	if (k == n || k == 0) return 1;
	
	double val = 1;
	for (int i=1; i<=(n-k); i++) {
		val *= double(k+i)/double(i);
	}
	return val;
}

int SetCardinality(Set *s)
{
	int count = 0;
	for (int i=0; i<s->arraysize; i++) {
		count += bitcount(s->bits[i]);
	}
	return count;
}

int bitcount (unsigned char n)  
{
	int count = 0 ;
	while (n)  {
		count++ ;
		n &= (n - 1) ;
	}
	return count ;
}

