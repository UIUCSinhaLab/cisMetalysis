/*
 *  Storage.h
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 7/6/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#ifndef _STORAGE_H_
#define _STORAGE_H_

struct Storage {
	int maxTupleSize;
	int topHowManyPerTupleSize;
	int ***tuples;
	double **scores;
	double *worstScores;
	int *worstScoreIndex;
	int *sizeOfStorage;
	void Initialize(int maxTupleSize, int topHowManyPerTupleSize);
	void Insert(int *motifIndexArray, int tupleSize, double score);
	bool ExtendTupleByOne(int *motifIndexArray, int curTupleIndex, int tupleSizeMinusOne, int curSingletIndex);
};

#endif

