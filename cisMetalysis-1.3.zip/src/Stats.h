/*
 *  Stats.h
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/20/09.
 *  Copyright 2009 University of Illinois. All rights reserved.
 *
 */

#ifndef _stats_h_
#define _stats_h_

#include "SetManager.h"

double ComputeEnrichmentPval(Set *U, Set *G, Set *M, Set *K, int *contable);
double CombinePvalues(double *pvals, int size);
double CombinePvaluesMaxK(double *pvals, int topk, int n);
int SetCardinality(Set *s);
int bitcount (unsigned char n);
double f (double x, void * params);
double Choose (int n, int k);

#endif

