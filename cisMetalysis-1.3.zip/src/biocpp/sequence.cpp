#include "sequence.h"
#include <math.h>

Sequence::Sequence(char *seq, int length, char *name)
{
  _seq = new char[length+1];
  strcpy(_seq,seq);
  _length = length;
  _name = new char[strlen(name)+1];
  strcpy(_name,name);
}

Sequence::~Sequence()
{
  delete [] _seq;
}

char *Sequence::Seq()
{
  return _seq;
}

int Sequence::Length()
{
  return _length;
}

char *Sequence::Name()
{
  return _name;
}

char Sequence::CharAt(int index)
{
  return _seq[index];
}

void Sequence::Print(int start, int stop)
{
  for (int i=start; i<=stop; i++) {
    printf("%c",_seq[i]);
  }
  printf("\n");
}


