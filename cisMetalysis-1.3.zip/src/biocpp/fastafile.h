#ifndef _fastafile_h_
#define _fastafile_h_

#include "sequence.h"

#include <vector>
using std::vector;
//#include <vector.h>

#define LINESIZE 10000

class FastaFile {
  vector<Sequence *> _sequences;
  int _numSequences;

public:
  FastaFile();
  void ReadFasta(char *filename);
  ~FastaFile();
  int Size();
  Sequence *operator[](int index);
};

#endif
