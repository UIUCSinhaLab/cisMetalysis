#include <cstdio>
#include <cstdlib>
//#include <stdio.h>
//#include <stdlib.h>
#include "fastafile.h"


FastaFile::FastaFile()
{
  _numSequences = 0;
}

void FastaFile::ReadFasta(char *filename)
{
  FILE *fp = fopen(filename,"r");
  if (fp == NULL) {
    printf("Error reading file %s\n",filename);
    exit(1);
  }

  int numSequences = -1; 
  char name[10000];
  char prevname[10000];

  int   current_length_estimate = LINESIZE;
  char *current_sequence = new char[current_length_estimate+1];
  int   cptr = 0;

  int ch = 0;
  while ((ch = fgetc(fp)) != EOF){
    if (ch == '>') {	
				// skip to end of line and copy as name
      int nptr = 0;
      while ((ch = fgetc(fp)) != EOF && ch != '\n' && ch != '\r') name[nptr++] = ch;
      if (ch == EOF) break;
      name[nptr] = 0; 
				// get ready for a new region
      if (numSequences > -1) {  // already seen a sequence ...
	current_sequence[cptr] = 0; 
	_sequences.push_back(new Sequence(current_sequence,cptr,prevname));
	numSequences++;
	cptr = 0;
      }
      else {                    // this is the first sequence
	numSequences = 0;
	cptr = 0;
      }
      strcpy(prevname,name);
    }
    if (ch != '\n' && ch != '\r') {
      if (cptr >= current_length_estimate) { 
	char *current_sequence_copy = current_sequence;
	current_length_estimate *= 2;
	current_sequence = new char[current_length_estimate];
	for (int ptr = 0; ptr < cptr; ptr++) current_sequence[ptr] = current_sequence_copy[ptr];
	delete current_sequence_copy;
      }
      current_sequence[cptr++] = ch;
    }
  }

  if (numSequences > -1) {
    current_sequence[cptr] = 0;
    _sequences.push_back(new Sequence(current_sequence,cptr,prevname));
    numSequences++;
  }

  _numSequences = numSequences;

  fclose(fp);
  delete [] current_sequence;
}

FastaFile::~FastaFile()
{
  for (int i=0; i<_numSequences; i++) delete _sequences[i];
}

int FastaFile::Size()
{
  return _numSequences;
}

Sequence *FastaFile::operator[] (int index)
{
  return _sequences[index];
}
