#ifndef _sequence_h_
#define _sequence_h_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

class Sequence {
  char  *_seq;
  int   _length;
  char  *_name;

public:
  static const int MAX_LINE_LENGTH = 100000;

  Sequence(char *seq, int length, char *name);
  ~Sequence();

  int   Length();
  char *Seq();
  char  CharAt(int index);
  void  Print(int start, int stop);
  char *Name();
};

#endif


