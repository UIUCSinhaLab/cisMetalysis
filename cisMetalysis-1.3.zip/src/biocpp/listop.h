#ifndef _listop_h_
#define _listop_h_

#include <vector>
#include <string>
#include <list>
#include <cstdlib>
using std::string;
using std::list;
using std::vector;

// Split doesnt create memory for the tokens returned,
// only creates memory for the list holding them.
list<char *> *Split(char *toks, char * str);

// Join creates memory for the string returned
char *Join(char *tok, list<char *> *l);
char *Join(char *tok, list<string> *l);

// Shift doesnt delete the memory taken by the head object 
char *Shift(list<char *> *l);

// These will create space for the list returned
list<int> *StringListToIntList(list<char *> *l);
vector<int> *StringListToIntVector(list<char *> *l);

// regular util functions
char* itoa( int value, char* result, int base );
void Chomp(char *line);

#endif
