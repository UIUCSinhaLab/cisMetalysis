/*
 *  Configuration.cpp
 *  Metalysis
 *
 *  Created by Saurabh Sinha Laptop on 6/18/09.
 *  Modified by Charles Blatti on 11/1/11.
 *  Copyright 2011 University of Illinois. All rights reserved.
 *
 */


#ifndef _classifier_h
#define _classifier_h

#include "Input.h"
#include "Configuration.h"
#include "SetManager.h"

extern struct Genes *gns; // will be allocated by the Reading function
extern struct GenesXMotifs *gXm; // will be allocated by the Reading function
extern struct GenesXLabels *gXl; // will be allocated by the Reading function
extern struct Configuration *config;
extern struct Storage storage;

struct Formula {
	int depth;
	int maxdepth;
	int *operators;
	int *motifindices;
	int contable[4];
	
	Formula();
	void Initialize(int maxdepth);
	~Formula();
	void Copy(Formula *other);
	void Print();
};

struct DecisionForest {
	Formula *trees;
	int *labels;
	double *pvals;
	int numTrees;
	int treesUsed; // only the first treesUsed trees were used in getting the best p-value
	DecisionForest(int numlabels, int maxdepth);
	~DecisionForest();
	void Copy(DecisionForest *other);
	void Print();
};

void EnumerateMotifCombinations();
double ProcessTuple(int *motifIndexArray, int tupleSize, int numStates, int numBools);
int GetNextSinglet(int curIndex);
int GetNumStates(int tSize, const char *mode);
bool GetNextTuple(int *array, int arraysize);
bool nextBoolTuple(int *array, int arraysize);
bool nextMotifSign(int *array, int arraysize);
bool consistencyCheck(int *roleArray, int *signArray, int exprLabel, int arraysize);
void consistencyTable(int **consistent, int tSize, int numBools, int numStates);
bool GetInitSign(int *subsetArray, int *signArray, int arraysize);
bool ValidTuple(int *array, int arraysize);
void PrintMotifTuple(int *motifIndexArray, int tupleSize);
void PrintBoolean(int tupleSize, int *motifSubset, int *motifSign);
double PredictSingleLabel(Set *available, int i, int c, int *motifIndexArray, int arraysize, DecisionForest *wdf, int treeIndex);
double RecursivelyExtendBoolean(double bestpval, Set *available, Set *G, Set *M, int *motifIndexArray, int arraysize, Set *usedM, int *usedliterals, int &usedliteralssize, DecisionForest *wdf, int treeIndex);


#endif

