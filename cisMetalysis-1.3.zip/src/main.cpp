#include <stdio.h>
#include <stdlib.h>
//#include <listop.h>
#include "Input.h"
#include "Configuration.h"
#include "SetManager.h"
#include "Classifier.h"
#include "Storage.h"

extern struct Genes *gns; // will be allocated by the Reading function
extern struct GenesXMotifs *gXm; // will be allocated by the Reading function
extern struct GenesXLabels *gXl; // will be allocated by the Reading function
extern struct Configuration *config;
extern struct Storage storage;

int main (int argc, char **argv) {
	if (argc < 3) { 
		printf("usage: %s <GenesXMotifs-filename> <GenesXLabels-filename> [-m <mode>] [-r <redundantmotifpairsfile>] [-f <motiffilterfile>] [-mincl <minClassesToCombine>] [-mts <maxTupleSize>] [-mtp <motifPvalThreshold>] [-nl0] [-nmaf] [-p <pattern>] [-req <requiredPattern>] [-nts]\n",argv[0]);
		exit(1);
	}
        char *genemotiffilename = argv[1];
	char *genelabelfilename = argv[2];
	int argbase = 3;
	Configure(argbase, argc, argv);
	ReadGenesXMotifs(genemotiffilename);
	ReadGenesXLabels(genelabelfilename);
	InitializeMotifSets(config->motifPvalThreshold);
	ReadMotifFilter(config->motiffilterfile);
	ReadRedundantMotifPairs(config->redundantmotifsfile);
	InitializeExpressionSets();
	storage.Initialize(config->maxTupleSize, config->topHowManyPerTupleSize);
	EnumerateMotifCombinations();
	return 0;
}

